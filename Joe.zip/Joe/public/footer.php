<footer class="joe_footer">
    <div class="joe_container">
        <div class="item">
            <?php $this->options->JFooter_Left() ?>
        </div>
        <?php if ($this->options->JBirthDay) : ?>
            <div class="item run">
                <span>建站 <strong class="joe_run__day">00</strong> 天 <strong class="joe_run__hour">00</strong> 时 <strong class="joe_run__minute">00</strong> 分 <strong class="joe_run__second">00</strong> 秒</span>
            </div>
        <?php endif; ?>
        <div class="item">
            <?php $this->options->JFooter_Right() ?>
        </div>
    </div>
</footer>

<?php if ($this->options->JFooter_Tabbar != NULL) : ?>
    <div class="joe_tabbar">
        <ul>
            <?php
            $txt = $this->options->JFooter_Tabbar;
            $string_arr = explode("\r\n", $txt);
            $long = count($string_arr);
            for ($i = 0; $i < $long; $i++) {
                $icon = explode("||", $string_arr[$i])[0];
                $name = explode("||", $string_arr[$i])[1];
                $url = explode("||", $string_arr[$i])[2];
            ?>
                <?php if ($txt) : ?>
                    <li class="joe_tabbar__item">
                        <a href="<?php $this->options->siteUrl(); ?><?php echo trim($url); ?>">
                            <i class="<?php echo trim($icon); ?> zm"></i><?php echo trim($name); ?>
                        </a>
                    </li>
                <?php endif; ?>
            <?php } ?>
        </ul>
    </div>
<?php endif; ?>

<div class="joe_action">
    <div class="joe_action_item scroll">
	<i class="fa fa-angle-up" aria-hidden="true"></i>
    </div>
</div>
<!--音乐播放器-->
<div style="position: fixed;top:50px;right:2%; z-index:9999;"><div id="CTPlayer" class="relative flex items-center"></div></div>
<script type="text/javascript" src="<?php $this->options->themeUrl('core/Player.js'); ?>"></script>
<!--音乐结束-->
<script>
    <?php
    $cookie = Typecho_Cookie::getPrefix();
    $notice = $cookie . '__typecho_notice';
    $type = $cookie . '__typecho_notice_type';
    ?>
    <?php if (isset($_COOKIE[$notice]) && isset($_COOKIE[$type]) && ($_COOKIE[$type] == 'success' || $_COOKIE[$type] == 'notice' || $_COOKIE[$type] == 'error')) : ?>
        Qmsg.info("<?php echo preg_replace('#\[\"(.*?)\"\]#', '$1', $_COOKIE[$notice]); ?>！")
    <?php endif; ?>
    <?php
    Typecho_Cookie::delete('__typecho_notice');
    Typecho_Cookie::delete('__typecho_notice_type');
    ?>
    console.log("%c页面加载耗时：<?php _endCountTime(); ?> | Theme By Joe", "color:#fff; background: linear-gradient(270deg, #986fee, #8695e6, #68b7dd, #18d7d3); padding: 8px 15px; border-radius: 0 15px 0 15px");
    <?php $this->options->JCustomScript() ?>
</script>

<?php $this->options->JCustomBodyEnd() ?>

<?php $this->footer(); ?>